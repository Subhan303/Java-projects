		<!-- footer -->
		<div id="footer">
      	<ul class="nav1">
         	<li><a href="index.php">Home</a>|</li>
     
            <li><a href="displayfacilities.php">Facilities</a>|</li>
            <li><a href="displayroomtypes.php">Room type</a>|</li>
            <li><a href="lodgeimages.php">Gallery</a>|</li>
            <li><a href="booking.php">Contact us</a></li>
         </ul>
         <div class="wrapper">
            <div class="fleft"></div>
           
         </div>
      </div>
	</div>
</body>
</html>