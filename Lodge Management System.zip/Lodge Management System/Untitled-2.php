<form>
<table width="200" border="1">
  <tr>
    <th scope="col">&ah2ghf;</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
</table>
