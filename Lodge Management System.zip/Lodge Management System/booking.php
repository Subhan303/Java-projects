<?php
include("header.php");
?>
		<!-- content -->
		<div id="content">
			<div class="wrapper">
            <div class="aside maxheight">
            	<!-- box begin -->
              <?php
			  include("leftsidebar.php");
			   ?>
               <!-- box end -->
            </div>
            <div class="content">
            	<div class="indent">
               	<h2>Our location</h2>
               	<img src="images/dharmasthala_entrance.jpg" alt="" width="264" height="209" /><img src="images/dharmasthala6.jpg" alt="" width="261" height="209" />
               	<div class="extra-wrap">
                  <p class="alt-top">Our hotel is located in the most spectacular part of Dharmasthala-.</p>
                  <p>Please feel free to come visit us at the following adress:</p>
                  <p>Dharmasthala</p>
                  <p>Tq: Belthangady </p>
                  <p>Dist: South canara</p>
                  <p>State: Karnataka ,India                  </p>
                  <dl class="contacts-list">
                   <dt>Chandrakant </dt>
                     <dd>1-800-412-4556</dd>
                     <dd>1-800-542-6448</dd>
                  </dl>
                  </div>
                  <div class="clear"></div>
               </div>
            </div>
         </div>
		</div>
		<!-- footer -->
	<?php
		include("footer.php");
		?>