<h3>Menu</h3>
                     <div class="gallery-images">
                        <ul>
                           
                           <li> 
                             <div align="center"><a href="index.php"><img src="img/Booking.com-250000+-hotels-Icon.png" alt="" width="80" height="69" /></a><br />
                         <strong>Room Booking</strong></div>
                          </li>
                           <li>
                             <div align="center"><strong><a href="visitorviewbooking.php"><img src="images/adminicons/Windows-View-Detail-icon.png" alt="" width="76" height="72" /></a><br />
                             Booking details</strong></div>
                          </li>
                           <li> 
                             <div align="center"><a href="visitorviewbilling.php"><img src="images/adminicons/Windows_icon_billing.png" alt="" width="77" height="68" /></a><br />
                             <strong>Payment</strong></div>
                          </li>
                           <li>
                             <div align="center"><a href="visitorsprofile.php"><img src="images/adminicons/profile.png" alt="" width="79" height="69" /></a><br />
                               <strong>Profile</strong></div>
                           </li>
                             <li> 
                               <div align="center"><a href="changepassword.php"><img src="images/adminicons/password_icon.png" alt="" width="80" height="76" /></a><br />
                               <strong>Change Password</strong></div>
                          </li>
                           <li>
                             <div align="center"><a href="visitlogout.php"><img src="images/adminicons/Cute-Ball-Logoff-icon.png" alt="" width="78" height="76" /></a><br />
                             <strong>Logout</strong></div>
                          </li>
                             
   
                       </ul>
                     </div>