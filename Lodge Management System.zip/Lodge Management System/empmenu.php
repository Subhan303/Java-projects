<?php
session_start();
?>
<ul>
                         <li> 
                           <div align="center"><strong><a href="viewrooms.php"><img src="images/adminicons/address_icon.png" alt="" width="76" height="74" /></a><br />
                          View Rooms</strong></div>
                           <div align="center"></div>
                      </li>
                       <li>
                         <div align="center"><strong><a href="bookroom.php"><img src="img/onlinebookingengine_icon.png" alt="" width="78" height="67" /></a><br />
                         Book Rooms</strong></div>
                      </li>
                      <li>
                        <div align="center"><strong><a href="viewbooking.php"><img src="img/DocumentIcon.png" alt="" width="81" height="68" /></a><br />
                        View _Booking
                        </strong></div>
                      </li>
                         <li>
                           <div align="center"><strong><a href="billingdetails.php"><img src="img/icons-02.png" alt="" width="80" height="71" /></a><br />
                          Billling</strong></div>
                      </li>
                       <li>
                         <div align="center"><strong><a href="viewvisitors.php"><img src="img/(R)Visitor_Reg_Icont.png" alt="" width="76" height="73" /></a><br />
                         Visitors</strong></div>
                      </li>
                         <li> 
                           <div align="center"><strong><a href="employees.php"><img src="images/adminicons/profile.png" alt="" width="72" height="72" /></a><br />
                          Profile</strong></div>
                      </li>
                       <li>
                         <div align="center"><strong><a href="logout.php"><img src="images/adminicons/Cute-Ball-Logoff-icon.png" alt="" width="83" height="72" /></a><br />
                         Logout</strong></div>
                      </li>
                   </ul>