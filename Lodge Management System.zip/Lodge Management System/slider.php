	<link href="slider/css/styles.css" type="text/css" media="all" rel="stylesheet" />
	<!-- Skitter Styles -->
	<link href="slider/css/skitter.styles.css" type="text/css" media="all" rel="stylesheet" />
	<!-- Skitter JS -->
	<script type="text/javascript" language="javascript" src="slider/js/jquery-1.6.3.min.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.animate-colors-min.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.skitter.min.js"></script>
	<!-- Init Skitter -->
	<script type="text/javascript" language="javascript">
		$(document).ready(function() {
			$('.box_skitter_large').skitter({
				theme: 'clean',
				numbers_align: 'center',
				progressbar: true, 
				dots: true, 
				preview: true
			});
		});
	</script>
		<div>
			<div class="border_box">
				<div class="box_skitter box_skitter_large">
					<ul>
                    <li><a href="#cubeRandom"><img src="slider/images/example/dharmasthala4.jpg" class="cubeRandom" /></a><div class="label_text"><p>Shree Kshethra Dharmasthala</p></div></li>
						<li><a href="#cube"><img src="slider/images/example/3page-img136988.jpg" class="cube" height="350" width="950"/></a><div class="label_text"><p></p></div></li>
                        <li><a href="#cubeRandom"><img src="slider/images/example/family_b.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>	
                        <li><a href="#cubeRandom"><img src="slider/images/example/Hotel.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>
                        <li><a href="#cubeRandom"><img src="slider/images/example/black-hotel-4.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>	
                        <li><a href="#cubeRandom"><img src="slider/images/example/port-cruises-luxury-hotel-barcelona.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>
                         <li><a href="#cube"><img src="slider/images/example/Petite-Queen.jpg" class="cube" /></a><div class="label_text"><p></p></div></li>
         	            <li><a href="#cubeRandom"><img src="slider/images/example/Hotel-Room-at-Home.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>
                         <li><a href="#cube"><img src="slider/images/example/032340525e86f00e51b6e8e9531e990a0fa4d7cc.jpg" class="cube" /></a><div class="label_text"><p></p></div></li>
                        <li><a href="#cubeRandom"><img src="slider/images/example/Excelsior_Hotel_Berlin_header_image.jpg" class="cubeRandom" /></a><div class="label_text"><p></p></div></li>
                        <li><a href="#cube"><img src="slider/images/example/standard450x300.jpg" class="cube" height="350" width="950"/></a><div class="label_text"><p></p></div></li>
           				<li><a href="#block"><img src="slider/images/example/dharmasthala626.jpg" class="block" /></a><div class="label_text"><p>Gate way of Dharmasthala</p></div></li>
                        
                        
					</ul>
				</div>
			</div>
		</div>