<?php
header("Location: ../loginpage.php");
?>