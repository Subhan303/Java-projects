<?php
$dbconnection = mysqli_connect("localhost","root","","lodging");
if(!$dbconnection)
{
	echo "Connection failed";
}
?>