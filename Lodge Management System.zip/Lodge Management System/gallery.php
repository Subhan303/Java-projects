﻿<?php  /*  Download projects from www.freestudentprojects.com */
include("header.php")
?>
		<!-- content -->
		<div id="content">
      	<div class="gallery">
            <ul>
               <li><a href="#"><img alt="" src="images/2page-img1.jpg" /></a></li>
               <li><a href="#"><img alt="" src="images/2page-img2.jpg" /></a></li>
               <li><a href="#"><img alt="" src="images/2page-img3.jpg" /></a></li>
               <li><a href="#"><img alt="" src="images/2page-img4.jpg" /></a></li>
               <li><a href="#"><img alt="" src="images/2page-img5.jpg" /></a></li>
               <li><a href="#"><img alt="" src="images/2page-img6.jpg" /></a></li>
            </ul>
         </div>
			<div class="container">
            <div class="aside maxheight">
            	<!-- box begin -->
               <div class="box maxheight">
               	<div class="inner">
                  	<h3>Browse Images</h3>
                     <div class="gallery-images">
                        <ul>
                           
                           <li> <a href="#"><img src="images/Photo0348.jpg" alt="" width="80" height="60" /></a></li>
                           <li><a href="#"><img src="images/Photo0318.jpg" alt="" width="80" height="60" /></a></li>
                           <li><a href="#"><img src="images/Photo0314.jpg" alt="" width="80" height="60" /></a></li>
                           <li><img src="images/Photo0328.jpg" alt="" width="80" height="60" /></li>
                           <li><a href="#"><img src="images/Photo0341.jpg" alt="" width="80" height="60" /></a></li>
                           <li><img src="images/Photo0343.jpg" alt="" width="80" height="60" /></li>
                           <li><a href="#"><img src="images/shareiq-423254-1374149506-965746-jpg-uploadimagesresorts-267.jpg" alt="" width="80" height="60" /></a></li>
                           <li><a href="#"><img alt="" src="images/3page-img12.jpg" /></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <!-- box end -->
            </div>
            <div class="content">
            	<div class="indent">
               	<h2>Lodge’s picture gallery</h2>
                  <div class="gallery-main png">
                  	<div class="inner"><img src="images/Photo0348.jpg" alt="" width="587" height="408" />
                  	  <div class="prev"><a href="#"><img alt="" src="images/prev.png" class="png" /></a></div>
                        <div class="next"><a href="#"><img src="images/next.png" alt="" width="32" height="411" class="png" /></a></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="clear"></div>
         </div>
		</div>
		<?php
		include("footer.php")
		?>