<form>
<table border=2>
<tr><th> <div align="left">Login ID : </div></th><td><label for="textfield"></label>
    <input type="text" name="login"></td></tr>
 <tr><th><div align="left">New Password : </div></th><td><label for="textfield2"></label>
     <input type="password" name="pswd"> </td>
    </tr>
    <tr>
      <th><div align="left">Conform Password : </div></th><td><label for="textfield2"></label>
     <input type="password" name="pswd2"> </td>
    </tr>
<tr><th colspan=2>
  <div align="center">
    <input name="conform" type="submit" value="Submit">
  </div></th></tr>
</table>
</form>
